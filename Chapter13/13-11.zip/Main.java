public class Main {
    public static void main(String []args) throws CloneNotSupportedException {
        Octagon oct = new Octagon(4);
        System.out.println(oct.getArea());
        Octagon oct2 = (Octagon)oct.clone();
        System.out.println(oct2.getArea());
        String wrds;
        if (oct.compareTo(oct2)==1){
            wrds = "Greater than";
        } else if (oct.compareTo(oct2)==0){
            wrds = "equal to";
        } else {
            wrds = "less than";
        }
        System.out.println("The first object is "+ wrds + " the second object.");
    }
}
