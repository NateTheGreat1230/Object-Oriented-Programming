public class Octagon extends GeometricObject implements Cloneable {
    double sidelen;
    public Octagon(){

    }
    public Octagon(double side){
        sidelen = side;
    }
    public double getArea(){
        double area;
        area = (2+(4/(Math.sqrt(2)))*sidelen*sidelen);
        return area;
    }
    @Override
    public String toString(){
        String ans =("Octagon: area = "+ getArea());
        return ans;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    int compareTo(Octagon octa){
        if (getArea() > octa.getArea()) {
            return 1;
        }else if (getArea() == octa.getArea()){
            return 0;
        }else {
            return -1;
        }
    }
}
