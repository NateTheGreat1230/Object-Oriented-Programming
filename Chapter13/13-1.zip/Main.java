import java.util.Scanner;

public class Main {
    public static void main(String []args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter Side1: ");
        double side1 = scan.nextDouble();
        System.out.print("Enter Side2: ");
        double side2 = scan.nextDouble();
        System.out.print("Enter Side3: ");
        double side3 = scan.nextDouble();
        System.out.print("Enter a color: ");
        String color = scan.next();
        System.out.print("filled true/false: ");
        boolean filled = scan.nextBoolean();

        Triangle tri = new Triangle(side1, side2, side3, color, filled);

        System.out.println(tri.toString());
    }
}
