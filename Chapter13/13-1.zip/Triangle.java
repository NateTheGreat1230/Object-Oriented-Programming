public class Triangle extends GeometricObject {
    double side1 = 1.0;
    double side2 = 1.0;
    double side3 = 1.0;
    String color;
    boolean filled;
    public Triangle(){

    }
    public Triangle(double s1, double s2, double s3){
        side1 = s1;
        side2 = s2;
        side3 = s3;
    }
    public Triangle(double s1, double s2, double s3, String color1, boolean filled1){
        side1 = s1;
        side2 = s2;
        side3 = s3;
        color = color1;
        filled = filled1;
    }
    double getArea(){
        double s;
        double area;
        s = ((side1+side2+side3)/2);
        area = Math.pow((s*(s-side1)*(s-side2)*(s-side3)), 0.5);
        return area;
    }
    double getPerimeter(){
        double perim;
        perim = (side1 + side2 + side3);
        return perim;
    }
    @Override
    public String toString(){
        String ans =("Triangle: area = "+ getArea() + ", perimeter = "+ getPerimeter() + ", color = " + color + ", filled = " + filled);
        return ans;
    }
}