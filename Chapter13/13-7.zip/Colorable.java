interface Colorable {
    String howToColor();
}
