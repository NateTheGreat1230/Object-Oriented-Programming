import java.util.Scanner;

public class Main {
    public static void main(String []args){
        Triangle tri[] = {new Triangle(1,2,2,"blue",true), new Triangle(2,3,4,"pink",false), new Triangle(3,6,8,"black",true), new Triangle(3,5,8,"orange",false), new Triangle(3,8,10,"green",true)};


        for (int i = 0; i < tri.length; i++) {
            System.out.println((i+1)+") " +tri[i].toString());
            System.out.println(tri[i].howToColor());
        }
    }
}
