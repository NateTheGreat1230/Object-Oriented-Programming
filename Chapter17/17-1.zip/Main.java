import java.io.*;
import java.util.*;
public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("Exercise17_01.txt");
        int[] nums = new int[100];
        Random num = new Random();
        for (int i = 0; i < 100; i++) {
            nums[i] = num.nextInt(1000);
            try (PrintWriter output = new PrintWriter(file);) {
                for (int j: nums) {
                    output.print(j+" ");
                }
            }
        }
    }
}