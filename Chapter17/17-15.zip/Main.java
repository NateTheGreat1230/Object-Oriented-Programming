import java.io.*;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) throws IOException {
        Scanner usr = new Scanner(System.in);
        System.out.print("Enter unencrypted file name: ");
        String filename1 = usr.nextLine();
        System.out.print("Enter encrypted file name: ");
        String filename2 = usr.nextLine();

        RandomAccessFile file1 = new RandomAccessFile(filename1, "rw");
        RandomAccessFile file2 = new RandomAccessFile(filename2, "rw");
        System.out.println(file1.read());

        try {
            int num = 0;
            while ((num = file1.read()) != -1) {
                file2.write(((byte)num) + 5);
            }
        }
        catch (IOException ex) {}
        System.out.println(file2.read());
        decrypt(filename2);
    }
    public static void decrypt(String filename2) throws IOException {
        Scanner usr = new Scanner(System.in);
        System.out.print("Enter unencrypted file name: ");
        String filename3 = usr.nextLine();

        RandomAccessFile file2 = new RandomAccessFile(filename2, "rw");
        RandomAccessFile file3 = new RandomAccessFile(filename3, "rw");

        try {
            int num;
            while ((num = file2.read()) != -1) {
                file3.write(((byte)(num))-5);
            }
        }
        catch (IOException ex) {}
        System.out.println(file3.read());
    }
}
