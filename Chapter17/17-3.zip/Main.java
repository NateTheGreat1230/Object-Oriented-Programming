import java.io.*;
import java.util.*;
public class Main {
    public static void main(String[] args) throws IOException {
        FileOutputStream file = new FileOutputStream("Exercise17_03.dat");
        int[] nums = new int[100];
        Random num = new Random();
        DataOutputStream out = new DataOutputStream(file);
        for (int i = 0; i < 100; i++) {
            nums[i] = num.nextInt(1000);
            try (out) {
                    out.writeInt(nums[i]);
            }catch (IOException ex){}
        }
        System.out.println(getTotal());
    }
    public static int getTotal() throws IOException {
        int total = 0;
        FileInputStream filein = new FileInputStream("Exercise17_03.dat");
        try (DataInputStream read = new DataInputStream(filein)){
            for (int i =0; i<100; i++) {
                total = total + read.readInt();
            }
        }catch (EOFException ex) {}
        return total;
    }
}