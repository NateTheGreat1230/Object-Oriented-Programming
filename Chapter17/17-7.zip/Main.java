import java.io.*;
public class Main {
    public static void main(String[] args) throws IOException {
        Loan loan1 = new Loan();
        Loan loan2 = new Loan(1.8, 10, 10000);
        try (
                ObjectOutputStream output = new ObjectOutputStream(new
                        FileOutputStream("Exercise17_07.dat"));
        ) {
            output.writeObject(loan1);
            output.writeObject(loan2);
        }
        catch (IOException ex) {
            System.out.println("File could not be opened");
        }
        outputData();
    }
    public static void outputData() throws IOException {
        int total = 0;
        FileInputStream filein = new FileInputStream("Exercise17_07.dat");
        try (DataInputStream read = new DataInputStream(filein)){
            for (int i =0; i<100; i++) {
                total = total + read.readInt();
            }
        }catch (EOFException ex) {}
        System.out.println(total);
    }
}
