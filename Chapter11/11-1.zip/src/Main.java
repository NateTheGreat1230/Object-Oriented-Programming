public class Main {
    public static void main(String []args){
        triangle tri = new triangle(3,4,5);
        System.out.println(tri.getArea());
        System.out.println(tri.getPerimeter());
        System.out.println(tri.toString());
    }
}
