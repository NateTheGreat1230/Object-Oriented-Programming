import java.util.Date;

public class Account {
    int id = 0;
    double balance = 0;
    double annualInterestRate = 0;
    double overdraft = 200;
    Date dateCreated  = new Date();

    Account(){

    }
    Account(int id1, double balance1, double interestRate){
        id = id1;
        balance = balance1;
        annualInterestRate = interestRate;

    }

    public int getId(){
        return this.id;
    }
    public double getBalance(){
        return this.balance;
    }
    double getMonthlyInterestRate(double annualInterestRate){
        double interest = this.annualInterestRate / 1200;
        return interest;

    }
    double getMonthlyInterest(double balance){
        double interest = (this.balance*getMonthlyInterestRate(this.annualInterestRate));
        return interest;

    }
    double withdraw(double withdrawamount){
        balance = balance - withdrawamount;
        return balance;
    }
    double deposit(double depamount){
        balance = balance + depamount;
        return balance;
    }
}
class savingsAccount extends Account{
     savingsAccount(int id1, double balance1, double interestRate){
         id = id1;
         balance = balance1;
         annualInterestRate = interestRate;
    }

    String toString1(){
        String ans = ("Userid = "+id+ ", balance = "+balance+", Interest rate = "+ annualInterestRate);
        return ans;
    }
}
class checkingAccount extends Account{
     checkingAccount(int id1, double balance1, double interestRate,double overdraftLimit){
        overdraft = overdraftLimit;
         id = id1;
         balance = balance1;
         annualInterestRate = interestRate;
    }

    String toString1(){
        String ans = ("Userid = "+id+ ", balance = "+balance+", Interest rate = "+ annualInterestRate+ ", Overdraft limit = "+overdraft);
        return ans;
    }
}
