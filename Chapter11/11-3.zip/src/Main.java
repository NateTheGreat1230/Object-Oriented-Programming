public class Main {
    public static void main(String []args){
       
        savingsAccount user3 = new savingsAccount(1122, 20000, 4.5);
        checkingAccount user4 = new checkingAccount(1122, 20000, 4.5,300);
        System.out.println(user3.toString1());
        System.out.println(user4.toString1());

    }
}
