import java.util.Scanner;
public class Main {
    public static void main(String []args){
        Scanner scan = new Scanner(System.in);
        Account[] users = new Account[10];
        for (int i = 0; i < 10; i++){
            users[i] = new Account(i,100,0.0);

        }
        int userid = 100;
        while (userid<10 && userid>=0) {
            System.out.print("Enter user id: ");
            userid = scan.nextInt();
            System.out.println();
        }
        int menu =100;
        while (menu<5 && menu>0){
            System.out.println("Main menu ");
            System.out.println("1: check balance");
            System.out.println("2: withdraw");
            System.out.println("3: deposit");
            System.out.println("4: exit");
            System.out.print("Choose one option: ");
            menu = scan.nextInt();
        }
        System.out.println(users[9].getBalance());
/*
        Account user1 = new Account(1122, 20000, 4.5);
        Account user2 = new Account();
        Account usr = new Account(i,100,0.0);

        System.out.println(user1.withdraw(2500));
        System.out.println(user1.deposit(3000));
        System.out.println(user1.getBalance());
        System.out.println(user1.getMonthlyInterest(user1.getBalance()));
        System.out.println(user1.dateCreated);
        System.out.println(user2.annualInterestRate);*/
    }
}
