import java.util.Scanner;
public class Main {
    public static void main(String []args){
        Scanner scan = new Scanner(System.in);
        Account[] users = new Account[10];
        for (int i = 0; i < 10; i++){
            users[i] = new Account(i,100,0.0);
        }
        boolean menu1 = false;
        while (!menu1) {
            boolean id = false;
            boolean loggedin = false;
            int usr = 1;
            while (!id) {
                System.out.print("Enter user id: ");
                int inp = scan.nextInt();
                if (inp < 10 && inp > 0) {
                    System.out.println("Welcome!");
                    usr = inp;
                    loggedin = true;
                    id = true;
                } else {
                    System.out.println("Incorrect id");
                    id = false;
                }
            }
            int menu = 100;

            while (loggedin) {
                System.out.println("Main menu ");
                System.out.println("1: check balance");
                System.out.println("2: withdraw");
                System.out.println("3: deposit");
                System.out.println("4: exit");
                System.out.print("Choose one option: ");
                menu = scan.nextInt();
                if (menu == 1){
                    System.out.println(users[usr].getBalance());
                } else if (menu == 2){
                    System.out.print("Enter an amount to withdraw: ");
                    double withdraw = scan.nextDouble();
                    users[usr].withdraw(withdraw);
                    System.out.println(users[usr].getBalance());
                } else if (menu == 3){
                    System.out.print("Enter an amount to deposit: ");
                    double deposit = scan.nextDouble();
                    users[usr].deposit(deposit);
                    System.out.println(users[usr].getBalance());
                } else if (menu == 4){
                    loggedin = false;
                } else {
                    System.out.println("Bad input");
                }
            }
        }


/*
        Account user1 = new Account(1122, 20000, 4.5);
        Account user2 = new Account();
        Account usr = new Account(i,100,0.0);

        System.out.println(user1.withdraw(2500));
        System.out.println(user1.deposit(3000));
        System.out.println(user1.getBalance());
        System.out.println(user1.getMonthlyInterest(user1.getBalance()));
        System.out.println(user1.dateCreated);
        System.out.println(user2.annualInterestRate);*/
    }
}
