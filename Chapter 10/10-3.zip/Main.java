public class Main {
    public static void main(String []args){
        MyInteger int1 = new MyInteger();
        System.out.println(int1.isEven(20));
        System.out.println(int1.isEven(21));
        System.out.println(int1.isOdd(20));
        System.out.println(int1.isOdd(21));
        System.out.println(int1.getInt());
        System.out.println(int1.isPrime(7));
        System.out.println(int1.isPrime(4));
        System.out.println(int1.parseInt("testing"));

    }
}
