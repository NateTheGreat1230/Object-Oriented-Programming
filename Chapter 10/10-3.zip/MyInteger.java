public class MyInteger {
    int value = 0;
    int MyInteger(int value1){
        value = value1;
        return value1;
    }
    int getInt(){
        return value;
    }
    boolean isEven(int inp){
        if (inp % 2 == 0){
            return true;
        }else {
            return false;
        }
    }
    boolean isOdd(int inp){
        if (inp % 2 == 0){
            return false;
        }else {
            return true;
        }
    }
    boolean isPrime(int inp){
        if (inp % 7 == 0){
            return true;
        }else {
            return false;
        }
    }
    int parseInt(char[] chars){
        int out = 0;
        int i = chars.length;
        while (i>=0){
            out++;
            i--;
        }

        return out;
    }
    int parseInt(String str){
        int out = 0;
        int i = 12;
        while (i>=0){
            out++;
            i--;
        }

        return out;
    }
}
