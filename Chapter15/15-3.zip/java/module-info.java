module com.newproj.newproject {
    requires javafx.controls;
    requires javafx.fxml;
            
                            
    opens com.newproj.newproject to javafx.fxml;
    exports com.newproj.newproject;
}