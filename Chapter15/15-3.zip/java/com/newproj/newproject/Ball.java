package com.newproj.newproject;
import javafx.scene.paint.Color;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;

public class Ball extends Pane {
    private Circle ballobj = new Circle(20,20,20);
    public Ball() {
        ballobj.setFill(Color.WHITE);
        ballobj.setStroke(Color.BLACK);
        getChildren().add(ballobj);
    }

    public void Left() {
        double num = ballobj.getCenterX() - 20;
        if (ballobj.getCenterX() > ballobj.getRadius()){
            ballobj.setCenterX(num);
        }
    }
    public void Right() {
        double num = ballobj.getCenterX() + 20;
        if (ballobj.getCenterX() < getWidth() - ballobj.getRadius()){
            ballobj.setCenterX(num);
        }
    }
    public void Down() {
        double num = ballobj.getCenterY() + 20;
        if (ballobj.getCenterY() < getHeight() - ballobj.getRadius()){
            ballobj.setCenterY(num);
        }
    }
    public void Up() {
        double num = ballobj.getCenterY() - 20;
        if (ballobj.getCenterY() > ballobj.getRadius()){
            ballobj.setCenterY(num);
        }
    }
}