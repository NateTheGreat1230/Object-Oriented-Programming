package com.newproj.newproject;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.scene.Scene;

public class Main extends Application {
     private Ball ball = new Ball();
@Override
    public void start(Stage primaryStage) {
        HBox Box = new HBox();

        Button up = new Button("Up");
        Button down = new Button("Down");
        Button left = new Button("Left");
        Button right = new Button("Right");
        Box.getChildren().add(left);
        Box.getChildren().add(up);
        Box.getChildren().add(down);
        Box.getChildren().add(right);
        BorderPane pane = new BorderPane();
        pane.setCenter(ball);
        pane.setBottom(Box);

    left.setOnAction(e -> ball.Left());
    right.setOnAction(e -> ball.Right());
    up.setOnAction(e -> ball.Up());
    down.setOnAction(e -> ball.Down());


    // Create a scene and place it in the stage
        Scene scene = new Scene(pane,200,200);
         primaryStage.setTitle("Move The Ball"); // Set the stage title
         primaryStage.setScene(scene); // Place the scene in the stage
         primaryStage.show(); // Display the stage
         }
}