package com.newproj.newproject;

import javafx.application.Application;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.scene.Scene;

public class Main extends Application {
     run rn = new run();
@Override
    public void start(Stage primaryStage) {
        HBox Box = new HBox();
        HBox Box1 = new HBox();

        Box1.getChildren().add(rn.out);
        Box.getChildren().add(rn.start);
        Box.getChildren().add(rn.inp);

        BorderPane pane = new BorderPane();
        pane.setTop(Box1);
        pane.setBottom(Box);

        rn.start.setOnMouseClicked(e -> rn.startMethod());

    // Create a scene and place it in the stage
        Scene scene = new Scene(pane,200,200);
         primaryStage.setTitle("Timer"); // Set the stage title
         primaryStage.setScene(scene); // Place the scene in the stage
         primaryStage.show(); // Display the stage
    }
}