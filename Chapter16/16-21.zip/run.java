

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public class run extends Pane {
    Button start = new Button("Start");
    TextArea inp = new TextArea();
    Label out = new Label();
    Media media = new Media("http://cs.armstrong.edu/liang/common/audio/anthem/anthem0.mp3");
    MediaPlayer sound = new MediaPlayer(media);
    public run() {
        getChildren().add(out);
        getChildren().add(inp);
        getChildren().add(start);
        inp.setPrefSize(100,20);
    }
    public void startMethod(){
        AtomicReference<String> user = new AtomicReference<>("");
        int num;
        user.set(inp.getText());
        num = Integer.parseInt(String.valueOf(user));
        while (num>0){
            System.out.println(num-1);
            out.setText(Integer.toString(num-1));
            try{
                TimeUnit.SECONDS.sleep(1);
            } catch(InterruptedException ex){}
            num--;
        }
        if (num == 0){
            sound.play();
            //out.setText("media is playing");
        } else {
            sound.pause();
            out.setText("media is stopped");
        }
    }
}