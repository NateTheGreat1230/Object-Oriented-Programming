package com.newproj.newproject;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Pane;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public class run extends Pane {
    Button start = new Button("Start");
    TextArea inp = new TextArea();
    Label out = new Label();
    public run() {
        getChildren().add(out);
        getChildren().add(inp);
        getChildren().add(start);
        inp.setPrefSize(100,20);
    }
    public void startMethod(){
        AtomicReference<String> user = new AtomicReference<>("");
        int num;
        user.set(inp.getText());
        num = Integer.parseInt(String.valueOf(user));
        count(num);

    }
    public void count(int num){
        while (num>0){
            System.out.println(num);
            String str = Integer.toString(num);
            out.setText(str);
            try{
                TimeUnit.SECONDS.sleep(1);
            } catch(InterruptedException ex){}

            num--;
        }
    }
}