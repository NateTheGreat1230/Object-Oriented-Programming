
import javafx.scene.paint.Color;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class Words extends Pane {
    Text wrds = new Text("Programing is fun");
    public Words() {
        getChildren().add(wrds);
    }

    public void red() {
        wrds.setStroke(Color.RED);
    }
    public void yellow() {
        wrds.setStroke(Color.YELLOW);
    }
    public void black() {
        wrds.setStroke(Color.BLACK);
    }
    public void orange() {
        wrds.setStroke(Color.ORANGE);
    }
    public void green() {
        wrds.setStroke(Color.GREEN);
    }

    public void Left() {
        double num = wrds.getX() - 20;
        if (wrds.getX() > wrds.getScaleX()){
            wrds.setX(num);
        }
    }

    public void Right() {
        double num = wrds.getX() + 20;
        if (wrds.getX() < getWidth() - 100){
            wrds.setX(num);
        }
    }

}