
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.scene.Scene;

public class Main extends Application {
     private Words words = new Words();
@Override
    public void start(Stage primaryStage) {
        HBox Box = new HBox();
        HBox Box1 = new HBox();
        ToggleGroup toggle = new ToggleGroup();
        Button left = new Button("Left");
        Button right = new Button("Right");
        RadioButton red = new RadioButton("Red");
        RadioButton yellow = new RadioButton("Yellow");
        RadioButton black = new RadioButton("Black");
        RadioButton orange = new RadioButton("Orange");
        RadioButton green = new RadioButton("Green");
        Box1.getChildren().add(red);
        Box1.getChildren().add(yellow);
        Box1.getChildren().add(black);
        Box1.getChildren().add(orange);
        Box1.getChildren().add(green);
        red.setToggleGroup(toggle);
        yellow.setToggleGroup(toggle);
        black.setToggleGroup(toggle);
        orange.setToggleGroup(toggle);
        green.setToggleGroup(toggle);

        Box.getChildren().add(left);
        Box.getChildren().add(right);
        Box1.setAlignment(Pos.CENTER);
        Box.setAlignment(Pos.CENTER);


        BorderPane pane = new BorderPane();
        pane.setTop(Box1);
        pane.setCenter(words);
        pane.setBottom(Box);

        left.setOnAction(e -> words.Left());
        right.setOnAction(e -> words.Right());

        red.setOnAction(e -> words.red());
        yellow.setOnAction(e -> words.yellow());
        black.setOnAction(e -> words.black());
        orange.setOnAction(e -> words.orange());
        green.setOnAction(e -> words.green());



    // Create a scene and place it in the stage
        Scene scene = new Scene(pane,400,200);
         primaryStage.setTitle("Radio Buttons"); // Set the stage title
         primaryStage.setScene(scene); // Place the scene in the stage
         primaryStage.show(); // Display the stage
         }
}