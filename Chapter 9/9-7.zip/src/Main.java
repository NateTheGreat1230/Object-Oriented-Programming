public class Main {
    public static void main(String []args){
        Account user1 = new Account(1122, 20000, 4.5);
        Account user2 = new Account();

        System.out.println(user1.withdraw(2500));
        System.out.println(user1.deposit(3000));
        System.out.println(user1.getBalance());
        System.out.println(user1.getMonthlyInterest(user1.getBalance()));
        System.out.println(user1.dateCreated);
        /*System.out.println(user2.annualInterestRate);*/
    }
}
