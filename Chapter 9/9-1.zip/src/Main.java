
public class Main {
    public static void main(String []args){
        Rectangle rect = new Rectangle(4, 40);
        Rectangle rect2 = new Rectangle(3.5, 35.9);

        System.out.println(rect.width+", "+rect.height+", "+rect.getArea()+", "+rect.getPerimeter());
        System.out.println(rect2.width+", "+rect2.height+", "+rect2.getArea()+", "+rect2.getPerimeter());

    }
}
